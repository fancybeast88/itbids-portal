import { PrismaClient, Role, UserStatus } from '@prisma/client';
import bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding database...');

  // Admin user
  const hash = await bcrypt.hash('Admin@1234', 10);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@itbids.pk' },
    update: {},
    create: {
      email: 'admin@itbids.pk',
      passwordHash: hash,
      role: Role.ADMIN,
      status: UserStatus.APPROVED,
    },
  });
  console.log('Admin user created:', admin.email);

  // Category credit costs
  const categories = [
    { category: 'Laptops',    cost: 2 },
    { category: 'Desktops',   cost: 2 },
    { category: 'Servers',    cost: 3 },
    { category: 'Networking', cost: 2 },
    { category: 'Firewall',   cost: 3 },
    { category: 'Storage',    cost: 2 },
    { category: 'Printers',   cost: 1 },
    { category: 'UPS',        cost: 1 },
  ];

  for (const cat of categories) {
    await prisma.categoryCreditCost.upsert({
      where: { category: cat.category },
      update: {},
      create: cat,
    });
  }
  console.log('Category credit costs seeded');

  // Email notification settings (singleton)
  await prisma.emailNotificationSettings.upsert({
    where: { id: 'singleton' },
    update: {},
    create: { id: 'singleton' },
  });
  console.log('Email notification settings initialized');

  console.log('Seeding complete!');
  console.log('Admin login: admin@itbids.pk / Admin@1234');
  console.log('IMPORTANT: Change the admin password after first login!');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
