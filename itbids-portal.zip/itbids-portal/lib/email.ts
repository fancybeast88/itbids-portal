import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export type EmailTemplate =
  | 'rfq-approved'
  | 'rfq-rejected'
  | 'rfq-unlocked'
  | 'quote-received'
  | 'quote-shortlisted'
  | 'credits-added'
  | 'account-approved'
  | 'account-pending'
  | 'admin-new-registration';

const subjects: Record<EmailTemplate, string> = {
  'rfq-approved':            'Your RFQ is now live — IT Bids Portal',
  'rfq-rejected':            'Your RFQ was not approved — IT Bids Portal',
  'rfq-unlocked':            'RFQ unlocked — IT Bids Portal',
  'quote-received':          'New quote received for your RFQ — IT Bids Portal',
  'quote-shortlisted':       'Your quote has been shortlisted — IT Bids Portal',
  'credits-added':           'Credits added to your account — IT Bids Portal',
  'account-approved':        'Account approved — Welcome to IT Bids Portal',
  'account-pending':         'Application received — IT Bids Portal',
  'admin-new-registration':  '[Admin] New registration pending approval',
};

function baseTemplate(content: string): string {
  return `
    <div style="font-family:Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#222">
      <div style="margin-bottom:24px">
        <span style="font-size:18px;font-weight:700;color:#185FA5">IT Bids Portal</span>
        <span style="font-size:12px;color:#888;margin-left:8px">Pakistan IT Procurement</span>
      </div>
      ${content}
      <hr style="border:none;border-top:1px solid #eee;margin:24px 0"/>
      <p style="font-size:11px;color:#aaa">IT Bids Portal · Karachi, Pakistan · <a href="${process.env.NEXTAUTH_URL}" style="color:#378ADD">itbids.pk</a></p>
    </div>
  `;
}

function renderTemplate(template: EmailTemplate, data: Record<string, any>): string {
  const portal = process.env.NEXTAUTH_URL || 'https://itbids.pk';
  const btnStyle = 'display:inline-block;background:#378ADD;color:#fff;padding:10px 22px;border-radius:6px;text-decoration:none;font-size:13px;margin-top:14px';

  const templates: Record<EmailTemplate, string> = {
    'rfq-approved': baseTemplate(`
      <h2 style="color:#0F6E56;margin-bottom:8px">Your RFQ is now live</h2>
      <p>Your RFQ <strong>"${data.rfqTitle}"</strong> has been approved by our admin team and is now visible to verified vendors on IT Bids Portal.</p>
      <p style="color:#555">Vendors will be able to unlock and respond with quotes. You will be notified by email when quotes come in.</p>
      <a href="${portal}/business/my-rfqs" style="${btnStyle}">View your RFQs</a>
    `),
    'rfq-rejected': baseTemplate(`
      <h2 style="color:#A32D2D;margin-bottom:8px">RFQ not approved</h2>
      <p>Your RFQ <strong>"${data.rfqTitle}"</strong> was not approved.</p>
      ${data.reason ? `<p><strong>Reason:</strong> ${data.reason}</p>` : ''}
      <p style="color:#555">Please review your RFQ details and resubmit, or contact our support team for assistance.</p>
      <a href="${portal}/business/post-rfq" style="${btnStyle}">Post a new RFQ</a>
    `),
    'rfq-unlocked': baseTemplate(`
      <h2 style="color:#185FA5;margin-bottom:8px">RFQ unlocked</h2>
      <p>You successfully unlocked <strong>"${data.rfqTitle}"</strong> using <strong>${data.creditsUsed} credits</strong>.</p>
      <p style="color:#555">Full details are now visible — business name, budget, specs, and contact information. You can now submit your quote.</p>
      <a href="${portal}/vendor/rfqs/${data.rfqId}" style="${btnStyle}">View &amp; Submit Quote</a>
    `),
    'quote-received': baseTemplate(`
      <h2 style="color:#185FA5;margin-bottom:8px">New quote received</h2>
      <p>A vendor has submitted a quote for your RFQ <strong>"${data.rfqTitle}"</strong>.</p>
      <table style="width:100%;border-collapse:collapse;margin:14px 0;font-size:13px">
        <tr><td style="padding:6px 0;color:#888">Vendor</td><td style="padding:6px 0">${data.vendorName}</td></tr>
        <tr><td style="padding:6px 0;color:#888">Quoted amount</td><td style="padding:6px 0;font-weight:700">PKR ${data.amount}</td></tr>
        <tr><td style="padding:6px 0;color:#888">Delivery</td><td style="padding:6px 0">${data.delivery}</td></tr>
      </table>
      <a href="${portal}/business/my-rfqs/${data.rfqId}/quotes" style="${btnStyle}">Review Quote</a>
    `),
    'quote-shortlisted': baseTemplate(`
      <h2 style="color:#185FA5;margin-bottom:8px">You have been shortlisted</h2>
      <p>Your quote for <strong>"${data.rfqTitle}"</strong> has been shortlisted by <strong>${data.buyerName}</strong>.</p>
      <p style="color:#555">The buyer may contact you directly soon. Keep your phone and email accessible.</p>
      <a href="${portal}/vendor/quotes" style="${btnStyle}">View my quotes</a>
    `),
    'credits-added': baseTemplate(`
      <h2 style="color:#0F6E56;margin-bottom:8px">Credits added</h2>
      <p><strong>${data.credits} credits</strong> have been successfully added to your IT Bids account.</p>
      <p style="font-size:20px;font-weight:700;color:#185FA5">New balance: ${data.balance} credits</p>
      <p style="color:#555">You can now unlock RFQs and submit quotes to win new business.</p>
      <a href="${portal}/vendor/rfqs" style="${btnStyle}">Browse RFQs</a>
    `),
    'account-approved': baseTemplate(`
      <h2 style="color:#0F6E56;margin-bottom:8px">Account approved — welcome!</h2>
      <p>Your IT Bids Portal account has been approved. You can now sign in and start using the portal.</p>
      ${data.role === 'VENDOR' ? '<p style="color:#555">As a vendor, you can browse RFQs, purchase credits, and submit quotes to win IT procurement contracts.</p>' : '<p style="color:#555">As a business, you can post RFQs and receive quotes from verified IT vendors across Pakistan.</p>'}
      <a href="${portal}/login" style="${btnStyle}">Sign in now</a>
    `),
    'account-pending': baseTemplate(`
      <h2 style="color:#854F0B;margin-bottom:8px">Application received</h2>
      <p>Thank you for registering on IT Bids Portal. Your account application is currently under review.</p>
      <p style="color:#555">We typically review applications within 24 hours on business days. You will receive an email at this address once your account is approved.</p>
      <p style="color:#555">If you have questions, contact us at <a href="mailto:support@itbids.pk" style="color:#378ADD">support@itbids.pk</a>.</p>
    `),
    'admin-new-registration': baseTemplate(`
      <h2 style="color:#185FA5;margin-bottom:8px">New registration pending approval</h2>
      <table style="width:100%;border-collapse:collapse;margin:14px 0;font-size:13px">
        <tr><td style="padding:6px 0;color:#888">Company</td><td style="padding:6px 0;font-weight:700">${data.companyName}</td></tr>
        <tr><td style="padding:6px 0;color:#888">Role</td><td style="padding:6px 0">${data.role}</td></tr>
        <tr><td style="padding:6px 0;color:#888">Email</td><td style="padding:6px 0">${data.email}</td></tr>
        <tr><td style="padding:6px 0;color:#888">City</td><td style="padding:6px 0">${data.city || '—'}</td></tr>
      </table>
      <a href="${portal}/admin/users" style="${btnStyle}">Review in admin panel</a>
    `),
  };

  return templates[template] || baseTemplate(`<p>${JSON.stringify(data)}</p>`);
}

export async function sendEmail({
  to,
  template,
  data = {},
}: {
  to: string;
  template: EmailTemplate;
  data?: Record<string, any>;
}) {
  try {
    // Check if this notification type is enabled
    const { prisma } = await import('./prisma');
    const settings = await prisma.emailNotificationSettings.findUnique({ where: { id: 'singleton' } });

    const settingKey: Record<EmailTemplate, keyof typeof settings | null> = {
      'rfq-approved':            'rfqApproved',
      'rfq-rejected':            'rfqRejected',
      'rfq-unlocked':            'rfqUnlocked',
      'quote-received':          'quoteReceived',
      'quote-shortlisted':       'quoteShortlisted',
      'credits-added':           'creditsAdded',
      'account-approved':        'accountApproved',
      'account-pending':         null,
      'admin-new-registration':  'newRegistrationAdmin',
    };

    const key = settingKey[template];
    if (key && settings && !(settings as any)[key]) {
      console.log(`Email notification '${template}' is disabled in settings. Skipping.`);
      return;
    }

    await resend.emails.send({
      from: process.env.FROM_EMAIL || 'noreply@itbids.pk',
      to,
      subject: subjects[template],
      html: renderTemplate(template, data),
    });

    console.log(`Email sent: ${template} to ${to}`);
  } catch (error) {
    console.error(`Failed to send email '${template}' to ${to}:`, error);
    // Don't throw — email failure should never break the main action
  }
}
