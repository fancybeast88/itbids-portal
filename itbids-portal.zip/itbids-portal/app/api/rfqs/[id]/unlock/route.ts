import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { sendEmail } from '@/lib/email';

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const user = session.user as any;
  if (user.role !== 'VENDOR') return NextResponse.json({ error: 'Only vendors can unlock RFQs' }, { status: 403 });

  const vendor = await prisma.vendorProfile.findUnique({ where: { userId: user.id } });
  if (!vendor) return NextResponse.json({ error: 'Vendor profile not found' }, { status: 404 });

  const rfq = await prisma.rfq.findUnique({ where: { id: params.id } });
  if (!rfq || rfq.status !== 'APPROVED') {
    return NextResponse.json({ error: 'RFQ not available for unlocking' }, { status: 400 });
  }

  // Check already unlocked
  const existing = await prisma.rfqUnlock.findUnique({
    where: { rfqId_vendorId: { rfqId: rfq.id, vendorId: vendor.id } },
  });
  if (existing) return NextResponse.json({ error: 'You have already unlocked this RFQ' }, { status: 400 });

  // Check credits
  if (vendor.credits < rfq.creditCost) {
    return NextResponse.json({
      error: `Insufficient credits. You need ${rfq.creditCost} credits but have ${vendor.credits}. Please top up.`,
    }, { status: 402 });
  }

  // Atomic transaction: deduct credits, record unlock, log transaction
  await prisma.$transaction([
    prisma.vendorProfile.update({
      where: { id: vendor.id },
      data:  { credits: { decrement: rfq.creditCost } },
    }),
    prisma.rfqUnlock.create({
      data: { rfqId: rfq.id, vendorId: vendor.id, creditsUsed: rfq.creditCost },
    }),
    prisma.creditTransaction.create({
      data: {
        vendorId: vendor.id,
        type:     'UNLOCK',
        credits:  -rfq.creditCost,
        status:   'CONFIRMED',
      },
    }),
    prisma.notification.create({
      data: {
        userId: user.id,
        type:   'rfq-unlocked',
        title:  'RFQ unlocked',
        body:   `You unlocked "${rfq.title}" for ${rfq.creditCost} credits.`,
      },
    }),
  ]);

  // Email vendor
  await sendEmail({
    to:       user.email,
    template: 'rfq-unlocked',
    data:     { rfqTitle: rfq.title, creditsUsed: rfq.creditCost, rfqId: rfq.id },
  });

  const newBalance = vendor.credits - rfq.creditCost;
  return NextResponse.json({ success: true, newBalance });
}
